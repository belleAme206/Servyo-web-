import React from 'react';
import ServiceGrid from '../../components/sections/explore/explore';

export default function ExplorePage() {
  return (
    <div className="min-h-screen">
      <ServiceGrid />
    </div>
  );
}
